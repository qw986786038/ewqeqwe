import 'package:getx_plus/getx_plus.dart';
import 'package:smart_admin/api/lcd_api.dart';
import 'package:smart_admin/entity/order/order_customer_entity.dart';
import 'package:smart_admin/entity/order/order_entity.dart';

/// 单个客户下的订单列表状态（分页）
class CustomerOrderBundle {
  final RxList<OrderEntity> orders = RxList.empty(growable: true);
  final RxBool loading = false.obs;
  final RxBool loadingMore = false.obs;
  int page = 0;
  int totalPages = 0;

  bool get hasMore => totalPages > 0 && page < totalPages;
}

class LcdOrderController extends GetController {
  Rxn<OrderCustomerEntity> currentCustomer = Rxn();
  RxList<OrderCustomerEntity> customers = RxList.empty(growable: true);
  Rxn<OrderEntity> currentOrder = Rxn();
  RxBool loadingOrder = false.obs;
  RxnInt expandedCustomerId = RxnInt();

  final Map<int, CustomerOrderBundle> _customerOrders = {};

  CustomerOrderBundle ordersOf(int customerId) => _customerOrders.putIfAbsent(customerId, CustomerOrderBundle.new);

  Future<void> setCustomerExpanded(OrderCustomerEntity customer, bool expanded) async {
    final int? id = customer.customer_id;
    if (id == null) return;
    if (expanded) {
      expandedCustomerId.value = id;
      currentCustomer.value = customer;
      await loadCustomerOrders(id, refresh: true);
      return;
    }
    if (expandedCustomerId.value == id) {
      expandedCustomerId.value = null;
    }
  }

  Future<void> loadCustomerOrders(int customerId, {bool refresh = false}) async {
    final bundle = ordersOf(customerId);
    if (bundle.loading.value || bundle.loadingMore.value) return;

    final int nextPage = refresh ? 1 : bundle.page + 1;
    if (!refresh && !bundle.hasMore) return;

    if (refresh) {
      bundle.loading.value = true;
      bundle.orders.clear();
      bundle.page = 0;
      bundle.totalPages = 0;
    } else {
      bundle.loadingMore.value = true;
    }

    try {
      final resp = await LcdApi.customerOrderList(page: nextPage, size: 20, param: {'customer_id': customerId});
      bundle.orders.addAll(resp.data ?? []);
      bundle.page = resp.page?.page ?? nextPage;
      bundle.totalPages = resp.page?.totalPages ?? 0;
    } finally {
      bundle.loading.value = false;
      bundle.loadingMore.value = false;
    }
  }

  Future<void> selectOrder(OrderCustomerEntity customer, OrderEntity order) async {
    final String? orderNo = order.order_no;
    if (orderNo == null || orderNo.isEmpty) return;
    currentCustomer.value = customer;
    if (currentOrder.value?.order_no == orderNo) return;

    currentOrder.value = null;
    loadingOrder.value = true;
    try {
      final resp = await LcdApi.orderDetail(orderNo: orderNo);
      currentOrder.value = resp.data;
    } finally {
      loadingOrder.value = false;
    }
  }
}
