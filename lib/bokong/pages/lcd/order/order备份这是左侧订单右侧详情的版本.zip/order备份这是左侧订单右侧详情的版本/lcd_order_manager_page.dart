import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:getx_plus/getx_plus.dart';
import 'package:smart_admin/api/lcd_api.dart';
import 'package:smart_admin/entity/order/order_customer_entity.dart';
import 'package:smart_admin/entity/order/order_entity.dart';
import 'package:smart_admin/pages/common/left_list_page.dart';
import 'package:smart_admin/pages/lcd/order/lcd_order_controller.dart';
import 'package:smart_admin/pages/lcd/program/lcd_program_material_table.dart';
import 'package:smart_admin/utils/ext.dart';
import 'package:smart_admin/widget/app_layout.dart';
import 'package:smart_admin/widget/glass_card.dart';
import 'package:smart_admin/widget/glass_list_item.dart';
import 'package:smart_admin/widget/info/info_item_column.dart';
import 'package:smart_admin/widget/info/info_item_row.dart';
import 'package:smart_admin/widget/info/info_item_widget.dart';
import 'package:smart_admin/widget/list/tag_widget.dart';
import 'package:smart_admin/widget/radial_gradient_dot.dart';

class LcdOrderManagerPage extends StatefulWidget {
  const LcdOrderManagerPage({super.key});

  @override
  State<LcdOrderManagerPage> createState() => _LcdOrderManagerPageState();
}

class _LcdOrderManagerPageState extends State<LcdOrderManagerPage> {
  final LcdOrderController _controller = Get.put(LcdOrderController());

  @override
  void dispose() {
    Get.delete<LcdOrderController>();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppLayout(
        maxContentWidth: 20000,
        startWidth: 400,
        widePadding: const EdgeInsets.only(left: 0, right: 0),
        start: GlassCard(
          blurEnabled: true,
          margin: EdgeInsetsGeometry.only(left: 16, top: 8, bottom: 8),
          opacityPreset: GlassOpacity.strong,
          child: LeftListPage(
            topViewBuilder: (context, obj) {
              return Padding(
                padding: EdgeInsetsGeometry.only(top: 16, left: 16, right: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('播放订单', style: context.theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                    Gap(16),
                    _orderStatsBar(context, obj),
                  ],
                ),
              );
            },
            api: ({int? page, int? size, Map<String, dynamic>? param}) {
              return LcdApi.customerList(page: (page ?? 0) + 1, size: size, param: param);
            },
            onDatasChanged: (datas) {
              _controller.customers.assignAll(datas.whereType<OrderCustomerEntity>());
            },
            itemBuilder: (BuildContext context, int index, value) {
              return _OrderCustomerListTile(key: ValueKey((value as OrderCustomerEntity).customer_id), item: value, controller: _controller);
            },
          ),
        ),
        main: GlassCard(
          blurEnabled: true,
          margin: EdgeInsetsGeometry.only(right: 8, top: 8, bottom: 8),
          padding: EdgeInsetsGeometry.symmetric(vertical: 16, horizontal: 16),
          child: Obx(() {
            if (_controller.loadingOrder.value && _controller.currentOrder.value == null) {
              return Center(child: CircularProgressIndicator());
            }
            final order = _controller.currentOrder.value;
            final customer = _controller.currentCustomer.value;
            if (order == null) {
              final hint = customer == null ? '请展开左侧客户并选择订单' : '请点击订单加载详情';
              return Center(child: Text(hint, style: context.theme.textTheme.titleMedium));
            }
            return Column(
              children: [
                GlassCard(
                  child: Container(
                    height: 68,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Text(
                          order.customer_name ?? '-',
                          style: context.theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Gap(16),
                        Container(height: 23, child: const VerticalDivider(width: 2)),
                        Gap(16),
                        Text(order.industry ?? '-', style: context.theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        Gap(16),
                        Container(height: 23, child: const VerticalDivider(width: 2)),
                        Gap(16),
                        Text(order.order_no ?? '-', style: context.theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        const Spacer(),
                        IconButton(onPressed: () {}, icon: const Icon(Icons.file_open_outlined)),
                        IconButton(onPressed: () {}, icon: const Icon(Icons.pause_circle_outline_outlined)),
                        IconButton(onPressed: () {}, icon: const Icon(Icons.outlined_flag_rounded)),
                        IconButton(onPressed: () {}, icon: const Icon(Icons.delete_outline)),
                      ],
                    ),
                  ),
                ),
                Gap(13),
                GlassCard(
                  child: Container(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    height: 120,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          InfoItemColumn(
                            children: [
                              InfoItemTextWidget(title: '订单编号', info: order.order_no ?? '-', twoLine: true),
                              InfoItemTextWidget(title: '收费类型', info: order.order_pay_label ?? '-'),
                            ],
                          ),
                          Container(height: 60, padding: const EdgeInsets.symmetric(horizontal: 30), child: const VerticalDivider()),
                          InfoItemColumn(
                            children: [
                              InfoItemTextWidget(title: '状态', info: _orderStatusLabel(order.status), twoLine: true),
                              InfoItemTextWidget(title: '订单天数', info: order.order_days == null ? '-' : '${order.order_days}天'),
                            ],
                          ),
                          Container(height: 60, padding: const EdgeInsets.symmetric(horizontal: 30), child: const VerticalDivider()),
                          InfoItemColumn(
                            children: [
                              InfoItemTextWidget(title: '素材数量', info: order.media_num?.toString() ?? '-', twoLine: true),
                              InfoItemTextWidget(title: '媒体点位(总)', info: '${order.terminal_list?.length ?? 0}'),
                            ],
                          ),
                          Container(height: 60, padding: const EdgeInsets.symmetric(horizontal: 30), child: const VerticalDivider()),
                          InfoItemColumn(
                            children: [
                              InfoItemTextWidget(title: '客户名称', info: order.customer_name ?? '-', twoLine: true),
                              InfoItemTextWidget(title: '客户编号', info: customer?.customer_no ?? '-'),
                            ],
                          ),
                          Container(height: 60, padding: const EdgeInsets.symmetric(horizontal: 30), child: const VerticalDivider()),
                          InfoItemColumn(
                            children: [
                              InfoItemTextWidget(title: '所属行业', info: order.industry ?? '-', twoLine: true),
                              InfoItemTextWidget(title: '付费类型', info: order.order_pay_label ?? '-'),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Gap(13),
                GlassCard(
                  child: Container(
                    height: 256,
                    alignment: Alignment.topCenter,
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          for (final item in order.items ?? <OrderItemEntity>[]) ...[orderInfoListItem(order, item), if (item != order.items!.last) Gap(16)],
                          if (order.items?.isEmpty ?? true)
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Text('暂无订单明细', style: context.theme.textTheme.bodyMedium),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                Gap(13),
                GlassCard(
                  child: Container(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                    constraints: const BoxConstraints(minHeight: 50),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          for (final terminal in order.terminal_list ?? <OrderTerminalEntity>[])
                            Padding(
                              padding: const EdgeInsets.only(right: 12),
                              child: TagLineWidget(tag: terminal.device_name ?? terminal.device_no ?? '-'),
                            ),
                          if (order.terminal_list?.isEmpty ?? true) Text('暂无关联终端', style: context.theme.textTheme.bodyMedium),
                        ],
                      ),
                    ),
                  ),
                ),
                Gap(13),
                Expanded(
                  child: GlassCard(
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                      child: InfoItemColumn(
                        children: [Text('监测要求', style: context.theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold))],
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }

  int _readObjCount(dynamic obj, String key) {
    if (obj is! Map) return 0;
    final Object? value = obj[key];
    if (value is int) return value;
    if (value is num) return value.toInt();
    return 0;
  }

  Widget _orderStatsBar(BuildContext context, dynamic obj) {
    final ThemeData theme = context.theme;
    final TextStyle? labelStyle = theme.textTheme.bodyMedium?.copyWith(fontSize: 12, height: 1);
    final TextStyle? labelStyle2 = theme.textTheme.bodyMedium?.copyWith(fontSize: 12, height: 1, color: Color(0xff19834E));
    final TextStyle? valueStyle = theme.textTheme.titleMedium?.copyWith(fontSize: 24, fontWeight: FontWeight.bold, height: 1);
    final TextStyle? valueStyle2 = theme.textTheme.titleMedium?.copyWith(fontSize: 18, fontWeight: FontWeight.bold, height: 1);
    final int customerCount = _readObjCount(obj, 'customer_count');
    final int orderCount = _readObjCount(obj, 'order_count');
    final int onplayCount = _readObjCount(obj, 'onplay_count');

    return Container(
      height: 50,
      alignment: Alignment.centerLeft,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text('客户总数', style: labelStyle),
          const Gap(4),
          Text('$customerCount', style: valueStyle),
          const Spacer(),
          Text('订单', style: labelStyle),
          const Gap(4),
          Text('$orderCount', style: valueStyle2),
          const Gap(12),
          Text('上刊', style: labelStyle2),
          const Gap(4),
          Text('$onplayCount', style: valueStyle2),
        ],
      ),
    );
  }

  String _orderStatusLabel(int? status) => status == 0 ? "上刊" : "下刊";

  String _playRuleLabel(int? playRule) {
    if (playRule == null) return '-';
    if (playRule == 1) return '循环播放';
    return playRule.toString();
  }

  Widget orderInfoListItem(OrderEntity order, OrderItemEntity item) {
    final period = item.play_period;
    final periodText = period == null ? '-' : '${period.start_time ?? '-'} - ${period.end_time ?? '-'}';
    final mediaType = mediaTypeOf(item.media_type);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InfoItemRow(
          children: [
            RadialGradientDot.info(borderWidth: 3),
            Gap(8),
            Text('${item.start_time ?? '-'} - ${item.end_time ?? '-'}', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 12)),
            Gap(8),
            Text(periodText, style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 12)),
          ],
        ),
        Gap(8),
        InfoItemRow(
          children: [
            Container(height: 50, child: VerticalDivider(width: 16)),
            Gap(8),
            Expanded(
              child: GlassCard(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Center(child: Text("上刊时间", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("下刊时间", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("订单天数", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("媒体类型", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("播放形式", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          flex: 2,
                          child: Center(child: Text("播放时段", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("广告时长", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("日播频次", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                        Expanded(
                          child: Center(child: Text("媒体点位", style: context.theme.listTileTheme.subtitleTextStyle?.copyWith(fontSize: 12))),
                        ),
                      ],
                    ),
                    Gap(6),
                    Divider(color: Color(0xffE1E1E1)),
                    Gap(6),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Center(child: Text(item.start_time ?? '-', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                        Expanded(
                          child: Center(child: Text(item.end_time ?? '-', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                        Expanded(
                          child: Center(
                            child: Text(item.order_days == null ? '-' : '${item.order_days}天', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14)),
                          ),
                        ),
                        Expanded(
                          child: Center(
                            child: TagWidget(tag: mediaType.label, color: mediaType.color, compact: true),
                          ),
                        ),
                        Expanded(
                          child: Center(child: Text(_playRuleLabel(item.play_rule), style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                        Expanded(
                          flex: 2,
                          child: Center(child: Text(periodText, style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                        Expanded(
                          child: Center(child: Text(item.duration == null ? '-' : '${item.duration}秒', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                        Expanded(
                          child: Center(child: Text(item.order_frequency?.toString() ?? '-', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                        Expanded(
                          child: Center(child: Text('${order.terminal_list?.length ?? 0}', style: context.theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 14))),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _OrderCustomerListTile extends StatelessWidget {
  const _OrderCustomerListTile({super.key, required this.item, required this.controller});

  final OrderCustomerEntity item;
  final LcdOrderController controller;

  @override
  Widget build(BuildContext context) {
    final theme = context.theme;
    final int? customerId = item.customer_id;

    return Obx(() {
      final bool isActive = controller.currentCustomer.value?.customer_id == customerId;
      return GlassCard(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        borderRadius: const BorderRadius.all(Radius.circular(8)),
        opacityPreset: isActive ? GlassOpacity.strong : GlassOpacity.medium,
        boxShadow: const [],
        child: Theme(
          data: theme.copyWith(
            dividerColor: Colors.transparent,
            splashFactory: NoSplash.splashFactory,
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
            hoverColor: Colors.transparent,
          ),
          child: ExpansionTile(
            shape: const Border(top: BorderSide.none, bottom: BorderSide.none),
            collapsedShape: const Border(top: BorderSide.none, bottom: BorderSide.none),
            tilePadding: const EdgeInsets.symmetric(horizontal: 12),
            childrenPadding: EdgeInsets.zero,
            onExpansionChanged: (expanded) => controller.setCustomerExpanded(item, expanded),
            title: Row(
              children: [
                Expanded(
                  child: Tooltip(
                    message: item.customer_name ?? '',
                    child: Text(item.customer_name ?? '-', style: theme.listTileTheme.titleTextStyle, overflow: TextOverflow.ellipsis),
                  ),
                ),
                TagWidget.info(tag: item.industry ?? '-'),
              ],
            ),
            children: customerId == null ? const [] : [_CustomerOrderList(customer: item, controller: controller)],
          ),
        ),
      );
    });
  }
}

class _CustomerOrderList extends StatelessWidget {
  const _CustomerOrderList({required this.customer, required this.controller});

  final OrderCustomerEntity customer;
  final LcdOrderController controller;

  @override
  Widget build(BuildContext context) {
    final int? customerId = customer.customer_id;
    if (customerId == null) return const SizedBox.shrink();

    return Obx(() {
      final bundle = controller.ordersOf(customerId);
      final theme = context.theme;

      if (bundle.loading.value && bundle.orders.isEmpty) {
        return const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))),
        );
      }
      if (bundle.orders.isEmpty) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Text('暂无订单', style: theme.textTheme.bodySmall),
        );
      }

      return Column(
        children: [
          for (final order in bundle.orders) _OrderListTile(customer: customer, order: order, controller: controller),
          if (bundle.hasMore)
            TextButton(
              onPressed: bundle.loadingMore.value ? null : () => controller.loadCustomerOrders(customerId),
              child: bundle.loadingMore.value ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('加载更多'),
            )
          else
            const SizedBox(height: 8),
        ],
      );
    });
  }
}

class _OrderListTile extends StatelessWidget {
  const _OrderListTile({required this.customer, required this.order, required this.controller});

  final OrderCustomerEntity customer;
  final OrderEntity order;
  final LcdOrderController controller;

  @override
  Widget build(BuildContext context) {
    final theme = context.theme;
    return Obx(() {
      final bool selected = controller.currentOrder.value?.order_no != null && controller.currentOrder.value?.order_no == order.order_no;
      return GlassListItem(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 4),
        selectedOpacityPreset : GlassOpacity.heavy,
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 8, offset: const Offset(0, 4))],
        selected: selected,
        onTap: () => controller.selectOrder(customer, order),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(order.order_no ?? '-', style: theme.listTileTheme.titleTextStyle?.copyWith(fontSize: 13), overflow: TextOverflow.ellipsis),
        ),
      );
    });
  }
}
